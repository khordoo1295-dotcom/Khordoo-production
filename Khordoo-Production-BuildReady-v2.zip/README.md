# ثبت تولید و دستمزد

Android app for offline daily production and monthly wage calculation.

## Build
This project uses Android Gradle Plugin 8.7.3 and Gradle 8.9. The included `BUILD_WORKFLOW.yml` is the GitHub Actions workflow content to place at `.github/workflows/main.yml`.

The app is offline-first and stores records locally in SQLite.
