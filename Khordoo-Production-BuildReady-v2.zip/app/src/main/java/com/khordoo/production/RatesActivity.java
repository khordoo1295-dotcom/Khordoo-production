package com.khordoo.production;
import android.app.*;import android.os.*;import android.graphics.Color;import android.text.InputType;import android.view.*;import android.widget.*;import java.util.*;
public class RatesActivity extends Activity{
 DB db; EditText month; ArrayList<EditText> fields=new ArrayList<>();
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_rates);db=new DB(this);month=findViewById(R.id.month);LinearLayout box=findViewById(R.id.ratesContainer);
  month.setText(Util.monthOf(Util.todayJalali()));
  for(int i=0;i<DB.TYPES.length;i++){TextView t=new TextView(this);t.setText(DB.TYPES[i]+"  |  تومان / "+DB.UNITS[i]);t.setTextSize(15);t.setTextColor(Color.DKGRAY);t.setPadding(0,14,0,3);box.addView(t);EditText e=new EditText(this);e.setHint("نرخ واحد");e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setTextSize(17);box.addView(e,new LinearLayout.LayoutParams(-1,58));fields.add(e);}
  findViewById(R.id.loadRates).setOnClickListener(v->load());findViewById(R.id.saveRates).setOnClickListener(v->save()); }
 void load(){String m=Util.normalize(month.getText().toString());if(!Util.validMonth(m)){toast("ماه را به صورت 1405/07 وارد کنید");return;}for(int i=0;i<fields.size();i++){double r=db.getRate(m,DB.TYPES[i]);fields.get(i).setText(r==0?"":Util.qty(r));}toast("نرخ‌های ذخیره‌شده بارگذاری شد");}
 void save(){String m=Util.normalize(month.getText().toString());if(!Util.validMonth(m)){toast("ماه را به صورت 1405/07 وارد کنید");return;}for(int i=0;i<fields.size();i++){String s=fields.get(i).getText().toString().trim();if(s.isEmpty()){toast("نرخ «"+DB.TYPES[i]+"» را وارد کنید");return;}double r;try{r=Double.parseDouble(s);}catch(Exception e){toast("نرخ نامعتبر است");return;}if(r<0){toast("نرخ نمی‌تواند منفی باشد");return;}db.saveRate(m,DB.TYPES[i],r);}toast("دستمزدهای ماه ذخیره شد");}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
