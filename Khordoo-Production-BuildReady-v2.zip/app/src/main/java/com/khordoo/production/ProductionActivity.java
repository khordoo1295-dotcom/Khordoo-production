package com.khordoo.production;
import android.app.*;import android.os.*;import android.content.*;import android.view.*;import android.widget.*;
public class ProductionActivity extends Activity{
 DB db; EditText date,qty; Spinner spinner; TextView unit; long editId=-1;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_production);db=new DB(this);date=findViewById(R.id.date);qty=findViewById(R.id.quantity);spinner=findViewById(R.id.activitySpinner);unit=findViewById(R.id.unit);
  date.setText(Util.todayJalali()); spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,DB.TYPES));
  spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?>p){}public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){unit.setText("واحد: "+DB.UNITS[pos]);}});
  findViewById(R.id.save).setOnClickListener(v->save());
 }
 void save(){String d=Util.normalize(date.getText().toString()),q=qty.getText().toString().trim();if(!Util.validDate(d)){toast("تاریخ شمسی معتبر وارد کنید؛ مثال 1405/07/05");return;}if(q.isEmpty()){toast("مقدار را وارد کنید");return;}double x;try{x=Double.parseDouble(q);}catch(Exception e){toast("مقدار نامعتبر است");return;}if(x<=0){toast("مقدار باید بیشتر از صفر باشد");return;}int p=spinner.getSelectedItemPosition();if(editId<0)db.addRecord(d,Util.monthOf(d),DB.TYPES[p],x);else db.updateRecord(editId,d,Util.monthOf(d),DB.TYPES[p],x);qty.setText("");toast(editId<0?"فعالیت ثبت شد":"رکورد ویرایش شد");editId=-1;findViewById(R.id.save).setEnabled(true);}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
