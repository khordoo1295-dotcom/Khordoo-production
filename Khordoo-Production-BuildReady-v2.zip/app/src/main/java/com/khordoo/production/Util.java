package com.khordoo.production;

import java.text.DecimalFormat;
import java.util.Locale;
import java.util.regex.Pattern;

public class Util {
    public static String monthOf(String date){
        String[] p=normalize(date).split("/");
        return p.length>=2 ? p[0]+"/"+String.format(Locale.US,"%02d",Integer.parseInt(p[1])) : "";
    }
    public static String normalize(String s){return s==null?"":s.trim().replace('-', '/');}
    public static boolean validDate(String s){
        String x=normalize(s); if(!Pattern.matches("\\d{4}/\\d{1,2}/\\d{1,2}",x)) return false;
        String[] p=x.split("/"); int y=Integer.parseInt(p[0]),m=Integer.parseInt(p[1]),d=Integer.parseInt(p[2]);
        if(y<1300||y>1500||m<1||m>12||d<1) return false;
        int max=m<=6?31:(m<=11?30:(isLeap(y)?30:29)); return d<=max;
    }
    public static boolean validMonth(String s){return s!=null&&Pattern.matches("\\d{4}/(0[1-9]|1[0-2])",normalize(s));}
    public static boolean isLeap(int y){int r=y%33; return r==1||r==5||r==9||r==13||r==17||r==22||r==26||r==30;}
    public static String money(double x){return new DecimalFormat("#,##0.##").format(x)+" تومان";}
    public static String qty(double x){return new DecimalFormat("#,##0.##").format(x);}
    // Gregorian -> Jalali, used only for a convenient default date.
    public static String todayJalali(){
        java.util.Calendar c=java.util.Calendar.getInstance();
        int[] j=gregorianToJalali(c.get(java.util.Calendar.YEAR),c.get(java.util.Calendar.MONTH)+1,c.get(java.util.Calendar.DAY_OF_MONTH));
        return String.format(Locale.US,"%04d/%02d/%02d",j[0],j[1],j[2]);
    }
    private static int[] gregorianToJalali(int gy,int gm,int gd){
        int[] gdm={0,31,28,31,30,31,30,31,31,30,31,30,31}; int gy2=gy-1600,gm2=gm-1,gd2=gd-1;
        int g=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400;
        for(int i=0;i<gm2;i++)g+=gdm[i]; if(gm2>1&&((gy%4==0&&gy%100!=0)||gy%400==0))g++;
        g+=gd2; int j=g-79; int jy=979+33*(j/12053); j%=12053; jy+=4*(j/1461); j%=1461;
        if(j>=366){jy+=(j-1)/365;j=(j-1)%365;} int jm=j<186?1+j/31:7+(j-186)/30; int jd=1+(j<186?j%31:(j-186)%30); return new int[]{jy,jm,jd};
    }
}
