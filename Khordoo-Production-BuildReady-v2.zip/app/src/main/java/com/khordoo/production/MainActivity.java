package com.khordoo.production;
import android.app.*;import android.os.*;import android.content.*;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  findViewById(R.id.btnProduction).setOnClickListener(v->startActivity(new Intent(this,ProductionActivity.class)));
  findViewById(R.id.btnRates).setOnClickListener(v->startActivity(new Intent(this,RatesActivity.class)));
  findViewById(R.id.btnReport).setOnClickListener(v->startActivity(new Intent(this,ReportActivity.class)));
  findViewById(R.id.btnHistory).setOnClickListener(v->startActivity(new Intent(this,HistoryActivity.class)));
 }
}
