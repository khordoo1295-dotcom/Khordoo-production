package com.khordoo.production;
import android.content.*; import android.database.*; import android.database.sqlite.*;

public class DB extends SQLiteOpenHelper {
 public static final String[] TYPES={"بلوک دیواری","بلوک سقفی","بلوک ۱۰ سانتی","بلوک ۱۵ سانتی","تیرچه","بلوک انبار شده","بار و تخلیه بلوک از انبار","تخلیه تیرچه"};
 public static final String[] UNITS={"عدد","عدد","عدد","عدد","متر","عدد","عدد","متر"};
 public DB(Context c){super(c,"production.db",null,2);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE records(id INTEGER PRIMARY KEY AUTOINCREMENT, shamsiDate TEXT NOT NULL, month TEXT NOT NULL, type TEXT NOT NULL, qty REAL NOT NULL)");d.execSQL("CREATE TABLE rates(month TEXT NOT NULL,type TEXT NOT NULL,rate REAL NOT NULL,PRIMARY KEY(month,type))");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){if(o<2){/* v1 schema is compatible */}}
 public long addRecord(String date,String month,String type,double qty){ContentValues v=new ContentValues();v.put("shamsiDate",date);v.put("month",month);v.put("type",type);v.put("qty",qty);return getWritableDatabase().insert("records",null,v);}
 public void updateRecord(long id,String date,String month,String type,double qty){ContentValues v=new ContentValues();v.put("shamsiDate",date);v.put("month",month);v.put("type",type);v.put("qty",qty);getWritableDatabase().update("records",v,"id=?",new String[]{String.valueOf(id)});}
 public void saveRate(String month,String type,double rate){ContentValues v=new ContentValues();v.put("month",month);v.put("type",type);v.put("rate",rate);getWritableDatabase().insertWithOnConflict("rates",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
 public double getRate(String month,String type){Cursor c=getReadableDatabase().rawQuery("SELECT rate FROM rates WHERE month=? AND type=?",new String[]{month,type});try{return c.moveToFirst()?c.getDouble(0):0;}finally{c.close();}}
 public Cursor records(String month){return getReadableDatabase().query("records",new String[]{"id","shamsiDate","month","type","qty"},"month=?",new String[]{month},null,null,"shamsiDate ASC,id ASC");}
 public Cursor allRecords(){return getReadableDatabase().query("records",new String[]{"id","shamsiDate","month","type","qty"},null,null,null,null,"shamsiDate DESC,id DESC");}
 public void delete(long id){getWritableDatabase().delete("records","id=?",new String[]{String.valueOf(id)});}
}
