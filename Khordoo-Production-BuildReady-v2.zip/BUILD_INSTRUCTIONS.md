ثبت تولید و دستمزد — پروژه Android

این پروژه برای ساخت APK با GitHub Actions آماده شده است.

روش استفاده در GitHub:
1) فایل ZIP را در ریشه Repository آپلود کنید.
2) فایل workflow داخل Repository باید ZIP را باز کند و سپس assembleDebug را اجرا کند.
3) در Actions اجرای Build Android APK را اجرا کنید.
4) پس از موفقیت، APK از بخش Artifacts قابل دریافت است.

Package: com.khordoo.production
Min SDK: 24
Compile/Target SDK: 35
Java: 17
Gradle: 8.9
Android Gradle Plugin: 8.7.3
